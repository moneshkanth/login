package in.techiesmart.techiesmart.Prevalent;

import in.techiesmart.techiesmart.Model.Users;

public class Prevalent
{
    private static Users currentonlineuser;
}
